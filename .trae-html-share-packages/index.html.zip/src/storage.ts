import type { Notebook } from './types'

const WORKSPACE_KEY = 'mnote.workspace.v1'
const UI_KEY = 'mnote.ui.v1'

export interface UiState {
  sectionId: string
  pageId: string
  mode: 'rich' | 'source'
}

export function loadWorkspace(): Notebook | null {
  try {
    const raw = localStorage.getItem(WORKSPACE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as Notebook
    if (!parsed || !Array.isArray(parsed.sections)) return null
    return parsed
  } catch {
    return null
  }
}

export function saveWorkspace(notebook: Notebook) {
  try {
    localStorage.setItem(WORKSPACE_KEY, JSON.stringify(notebook))
  } catch {
    // 存储空间不足时静默失败，避免打断编辑
  }
}

export function loadUiState(): UiState | null {
  try {
    const raw = localStorage.getItem(UI_KEY)
    if (!raw) return null
    return JSON.parse(raw) as UiState
  } catch {
    return null
  }
}

export function saveUiState(state: UiState) {
  try {
    localStorage.setItem(UI_KEY, JSON.stringify(state))
  } catch {
    // 忽略
  }
}

export function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`
}
