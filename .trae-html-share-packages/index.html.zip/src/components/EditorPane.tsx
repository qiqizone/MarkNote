import { useEffect, useRef, useState } from 'react'
import { EditorContent, useEditor } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import Link from '@tiptap/extension-link'
import Table from '@tiptap/extension-table'
import TableRow from '@tiptap/extension-table-row'
import TableHeader from '@tiptap/extension-table-header'
import TableCell from '@tiptap/extension-table-cell'
import { Markdown } from 'tiptap-markdown'
import CodeMirror from '@uiw/react-codemirror'
import { markdown as markdownLanguage } from '@codemirror/lang-markdown'
import { EditorView } from '@codemirror/view'
import type { EditorMode, NotePage, PageWidth } from '../types'

const extensions = [
  StarterKit.configure({
    heading: { levels: [1, 2, 3] },
    codeBlock: { HTMLAttributes: { class: 'md-code-block' } },
  }),
  Link.configure({
    openOnClick: false,
    autolink: true,
    HTMLAttributes: { rel: 'noopener noreferrer' },
  }),
  Table.configure({ resizable: false }),
  TableRow,
  TableHeader,
  TableCell,
  Placeholder.configure({
    emptyNodeClass: 'is-editor-empty',
    placeholder: '开始记录… 支持 Markdown 快捷语法：## 标题、- 列表、``` 代码块',
  }),
  Markdown.configure({
    html: false,
    tightLists: true,
    bulletListMarker: '-',
    linkify: true,
    transformPastedText: true,
    transformCopiedText: true,
  }),
]

function readMarkdown(editor: { storage: unknown }) {
  const storage = editor.storage as { markdown?: { getMarkdown: () => string } }
  return storage.markdown?.getMarkdown() ?? ''
}

function RichEditor({
  markdown,
  onChange,
}: {
  markdown: string
  onChange: (value: string) => void
}) {
  const editor = useEditor({
    extensions,
    content: markdown,
    autofocus: false,
    editorProps: {
      attributes: { class: 'prose', spellcheck: 'false' },
    },
    onUpdate: ({ editor: current }) => {
      onChange(readMarkdown(current))
    },
  })

  return <EditorContent editor={editor} />
}

function SourceEditor({
  value,
  onChange,
}: {
  value: string
  onChange: (value: string) => void
}) {
  return (
    <div className="source-editor">
      <CodeMirror
        value={value}
        onChange={onChange}
        extensions={[markdownLanguage(), EditorView.lineWrapping]}
        basicSetup={{
          lineNumbers: false,
          foldGutter: false,
          highlightActiveLine: false,
          highlightActiveLineGutter: false,
          autocompletion: false,
        }}
      />
    </div>
  )
}

interface Props {
  page: NotePage
  mode: EditorMode
  lastSaved: number
  onModeChange: (mode: EditorMode) => void
  onMarkdownChange: (markdown: string) => void
  onTitleChange: (title: string) => void
  onZoomChange: (zoom: number) => void
  onWidthChange: (width: PageWidth) => void
}

function formatSavedTime(timestamp: number) {
  const date = new Date(timestamp)
  const hour = `${date.getHours()}`.padStart(2, '0')
  const minute = `${date.getMinutes()}`.padStart(2, '0')
  return `${hour}:${minute}`
}

const WIDTH_OPTIONS: Array<{ value: PageWidth; label: string }> = [
  { value: 'narrow', label: '窄' },
  { value: 'standard', label: '标准' },
  { value: 'wide', label: '宽' },
]

export default function EditorPane({
  page,
  mode,
  lastSaved,
  onModeChange,
  onMarkdownChange,
  onTitleChange,
  onZoomChange,
  onWidthChange,
}: Props) {
  const previousMode = useRef(mode)
  const [richKey, setRichKey] = useState(0)

  useEffect(() => {
    if (mode === 'rich' && previousMode.current === 'source') {
      setRichKey((key) => key + 1)
    }
    previousMode.current = mode
  }, [mode])

  const charCount = page.markdown.replace(/\s+/g, '').length
  const zoomStep = (delta: number) => {
    const next = Math.min(200, Math.max(50, page.zoom + delta))
    onZoomChange(next)
  }

  return (
    <div className="doc">
      <div className="doc-head">
        <input
          className="doc-title"
          value={page.title}
          placeholder="无标题页面"
          aria-label="页面标题"
          onChange={(event) => onTitleChange(event.target.value)}
        />
        <div className="mode-seg" role="group" aria-label="编辑模式">
          <button
            type="button"
            className={mode === 'rich' ? 'active' : ''}
            onClick={() => onModeChange('rich')}
          >
            富文本
          </button>
          <button
            type="button"
            className={mode === 'source' ? 'active' : ''}
            onClick={() => onModeChange('source')}
          >
            源码
          </button>
        </div>
      </div>

      <div className="doc-meta-row">
        <div className="meta">
          <span className="save-dot" />
          已保存 {formatSavedTime(lastSaved)}
          <span className="meta-divider">·</span>
          约 {charCount} 字
          <span className="meta-divider">·</span>
          {mode === 'rich' ? '所见即所得' : 'Markdown 源码'}
        </div>
        <div className="doc-controls">
          <div className="width-seg" role="group" aria-label="页宽">
            {WIDTH_OPTIONS.map((option) => (
              <button
                key={option.value}
                type="button"
                className={page.width === option.value ? 'active' : ''}
                onClick={() => onWidthChange(option.value)}
              >
                {option.label}
              </button>
            ))}
          </div>
          <div className="zoom">
            <button type="button" onClick={() => zoomStep(-10)} title="缩小">
              −
            </button>
            <span
              className="zoom-label"
              title="双击恢复 100%"
              onDoubleClick={() => onZoomChange(100)}
            >
              {page.zoom}%
            </span>
            <button type="button" onClick={() => zoomStep(10)} title="放大">
              ＋
            </button>
          </div>
        </div>
      </div>

      <div className="doc-scroll">
        <div
          className={`sheet width-${page.width}`}
          style={{ zoom: page.zoom / 100 } as React.CSSProperties}
        >
          {mode === 'rich' ? (
            <RichEditor
              key={`${page.id}-${richKey}`}
              markdown={page.markdown}
              onChange={onMarkdownChange}
            />
          ) : (
            <SourceEditor value={page.markdown} onChange={onMarkdownChange} />
          )}
        </div>
      </div>
    </div>
  )
}
