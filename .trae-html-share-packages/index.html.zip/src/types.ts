export type PageWidth = 'narrow' | 'standard' | 'wide'

export type EditorMode = 'rich' | 'source'

export interface NotePage {
  id: string
  title: string
  markdown: string
  createdAt: number
  updatedAt: number
  zoom: number
  width: PageWidth
}

export interface NoteSection {
  id: string
  name: string
  color: string
  pages: NotePage[]
}

export interface Notebook {
  id: string
  name: string
  sections: NoteSection[]
}
