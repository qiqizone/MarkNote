import { useCallback, useEffect, useState } from 'react'
import SectionTabs from './components/SectionTabs'
import PageList from './components/PageList'
import EditorPane from './components/EditorPane'
import { createSeedNotebook } from './seed'
import { loadUiState, loadWorkspace, saveUiState, saveWorkspace, uid } from './storage'
import type { EditorMode, NotePage, Notebook, PageWidth } from './types'

const SECTION_COLORS = [
  '#6F6FFF',
  '#0D9488',
  '#2563EB',
  '#C2410C',
  '#7C3AED',
  '#DB2777',
  '#0891B2',
  '#059669',
]

function resolveInitial(notebook: Notebook) {
  const ui = loadUiState()
  if (ui) {
    const section = notebook.sections.find((item) => item.id === ui.sectionId)
    if (section) {
      const page = section.pages.find((item) => item.id === ui.pageId) ?? section.pages[0]
      return { sectionId: section.id, pageId: page?.id ?? '', mode: ui.mode }
    }
  }
  const section = notebook.sections.find((item) => item.id === 'sec-cpp') ?? notebook.sections[0]
  return {
    sectionId: section?.id ?? '',
    pageId: section?.pages[0]?.id ?? '',
    mode: 'rich' as EditorMode,
  }
}

export default function App() {
  const [notebook, setNotebook] = useState<Notebook>(() => loadWorkspace() ?? createSeedNotebook())
  const [activeSectionId, setActiveSectionId] = useState(() => resolveInitial(notebook).sectionId)
  const [activePageId, setActivePageId] = useState(() => resolveInitial(notebook).pageId)
  const [mode, setMode] = useState<EditorMode>(() => resolveInitial(notebook).mode)
  const [query, setQuery] = useState('')
  const [lastSaved, setLastSaved] = useState(() => Date.now())

  const activeSection = notebook.sections.find((section) => section.id === activeSectionId)
  const activePage = activeSection?.pages.find((page) => page.id === activePageId)

  useEffect(() => {
    const timer = window.setTimeout(() => {
      saveWorkspace(notebook)
      setLastSaved(Date.now())
    }, 600)
    return () => window.clearTimeout(timer)
  }, [notebook])

  useEffect(() => {
    saveUiState({ sectionId: activeSectionId, pageId: activePageId, mode })
  }, [activeSectionId, activePageId, mode])

  const updatePage = useCallback(
    (pageId: string, patch: Partial<NotePage>, touch = true) => {
      setNotebook((previous) => ({
        ...previous,
        sections: previous.sections.map((section) => ({
          ...section,
          pages: section.pages.map((page) =>
            page.id === pageId
              ? {
                  ...page,
                  ...patch,
                  updatedAt: touch ? Date.now() : page.updatedAt,
                }
              : page,
          ),
        })),
      }))
    },
    [],
  )

  const addPage = (sectionId: string) => {
    const target = notebook.sections.find((section) => section.id === sectionId)
    if (!target) return
    const index = target.pages.length + 1
    const newPage: NotePage = {
      id: uid('page'),
      title: `未命名页面 ${index}`,
      markdown: `# 未命名页面 ${index}\n\n开始记录…`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      zoom: 100,
      width: 'standard' as PageWidth,
    }
    setNotebook((previous) => ({
      ...previous,
      sections: previous.sections.map((section) =>
        section.id === sectionId ? { ...section, pages: [...section.pages, newPage] } : section,
      ),
    }))
    setActiveSectionId(sectionId)
    setActivePageId(newPage.id)
    setQuery('')
  }

  const deletePage = (pageId: string) => {
    if (!activeSection) return
    const page = activeSection.pages.find((item) => item.id === pageId)
    if (!page) return
    if (!window.confirm(`删除页面「${page.title}」？此操作不可恢复。`)) return

    const remaining = activeSection.pages.filter((item) => item.id !== pageId)
    setNotebook((previous) => ({
      ...previous,
      sections: previous.sections.map((section) =>
        section.id === activeSectionId ? { ...section, pages: remaining } : section,
      ),
    }))
    if (pageId === activePageId) {
      setActivePageId(remaining[0]?.id ?? '')
    }
  }

  const addSection = () => {
    const index = notebook.sections.length
    const newSection = {
      id: uid('sec'),
      name: `新分区 ${index + 1}`,
      color: SECTION_COLORS[index % SECTION_COLORS.length],
      pages: [] as NotePage[],
    }
    setNotebook((previous) => ({
      ...previous,
      sections: [...previous.sections, newSection],
    }))
    setActiveSectionId(newSection.id)
    setActivePageId('')
  }

  const renameSection = (sectionId: string, name: string) => {
    setNotebook((previous) => ({
      ...previous,
      sections: previous.sections.map((section) =>
        section.id === sectionId ? { ...section, name } : section,
      ),
    }))
  }

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const modifier = event.ctrlKey || event.metaKey
      if (modifier && event.key.toLowerCase() === 'e') {
        event.preventDefault()
        setMode((current) => (current === 'rich' ? 'source' : 'rich'))
      }
      if (modifier && event.key.toLowerCase() === 's') {
        event.preventDefault()
        saveWorkspace(notebook)
        setLastSaved(Date.now())
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [notebook])

  return (
    <div className="app">
      <header className="topbar">
        <div className="notebook">
          <span className="notebook-mark" />
          <span className="notebook-name">{notebook.name}</span>
          <svg className="notebook-caret" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
            <path d="M2 4l3 3 3-3" fill="none" stroke="currentColor" strokeWidth="1.4" />
          </svg>
        </div>

        <SectionTabs
          sections={notebook.sections}
          activeSectionId={activeSectionId}
          onSelect={(sectionId) => {
            const section = notebook.sections.find((item) => item.id === sectionId)
            setActiveSectionId(sectionId)
            setActivePageId(section?.pages[0]?.id ?? '')
            setQuery('')
          }}
          onAdd={addSection}
          onRename={renameSection}
        />

        <div className="search">
          <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true">
            <circle cx="6" cy="6" r="4.2" fill="none" stroke="currentColor" strokeWidth="1.4" />
            <path d="M9.2 9.2L12.5 12.5" stroke="currentColor" strokeWidth="1.4" />
          </svg>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="搜索全部笔记"
            aria-label="搜索笔记"
          />
          {query && (
            <button type="button" className="search-clear" onClick={() => setQuery('')} title="清空">
              ×
            </button>
          )}
        </div>

        <div className="shortcut-hint">Ctrl+E 切换模式</div>
      </header>

      <div className="main">
        {activePage ? (
          <EditorPane
            key={activePage.id}
            page={activePage}
            mode={mode}
            lastSaved={lastSaved}
            onModeChange={setMode}
            onMarkdownChange={(markdown) => updatePage(activePage.id, { markdown })}
            onTitleChange={(title) => updatePage(activePage.id, { title })}
            onZoomChange={(zoom) => updatePage(activePage.id, { zoom }, false)}
            onWidthChange={(width) => updatePage(activePage.id, { width }, false)}
          />
        ) : (
          <div className="doc empty-doc">
            <div className="empty-state">
              <div className="empty-title">这个分区还没有页面</div>
              <div className="empty-sub">新建一页，开始记录你的第一条笔记。</div>
              <button
                type="button"
                className="primary-btn"
                onClick={() => addPage(activeSectionId)}
              >
                新建页面
              </button>
            </div>
          </div>
        )}

        <PageList
          sections={notebook.sections}
          activeSectionId={activeSectionId}
          activePageId={activePageId}
          query={query}
          onSelect={(sectionId, pageId) => {
            setActiveSectionId(sectionId)
            setActivePageId(pageId)
            setQuery('')
          }}
          onAdd={() => addPage(activeSectionId)}
          onDelete={deletePage}
        />
      </div>
    </div>
  )
}
